# LC-DataCompany
 Chdata's Data Company Mod for Lethal Company

 I spent two weeks adding stale bread to this game. You better fucking love it.

## Scrap items
- Stale Bread
	- Compatible with teleporters. Try collecting 4 of them!
![Stale Bread](https://i.imgur.com/0al9gvg.png)

# Compatibility:
It is *unpredictable* whether or not this mod is compatible with other mods. In general, this one should not cause much issue with anything else.

If another mod patches `DropAllHeldItems()` directly, it may conflict with this mod's Prefix Patch of that function.

I have tested it with the following mods and everything was **a-okay**:

-`BetterTelporter` by `SirTyler`

-`FasterItemDropShip` by `FlipMods`

-`LethalThings` by `Evaisa`

-`Antiphobia` by `Chdata`

-`NecoArcHoarderBugMod` by `Chdata`

# Installation Instructions
Use your favorite mod manager to install!

All players must have the mod installed.

The "datacompany.assetbundle" file belongs in the same folder as "DataCompanyMod.dll". It contains the model and sounds.

Check out the config file for settings!

Remember your mod manager can open config settings in the Config Editor!

# Contact
You can find me on the Lethal Company Modding Discord. https://discord.com/channels/1168655651455639582/1189078708657598484

Twitter: https://twitter.com/Chdata

# Known Bugs:
- None!

# Credits
Thanks to the Lethal Company Modding Discord for teaching me the ropes!
https://discord.gg/v5t3KkEdsv

Thanks to `bogdanzloy20280` for the bread model!
https://sketchfab.com/3d-models/bread-ce86584fa4e240239f6325146be7d76f#download

# Updates

	- v1.0.3
		- Updated to use Evaisa-LethalLib-0.9.0

	- v1.0.0
		- Release
